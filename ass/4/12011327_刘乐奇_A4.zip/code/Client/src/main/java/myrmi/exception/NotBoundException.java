package myrmi.exception;

public class NotBoundException extends java.lang.Exception {
    public NotBoundException() {
        super();
    }

    public NotBoundException(String s) {
        super(s);
    }
}
